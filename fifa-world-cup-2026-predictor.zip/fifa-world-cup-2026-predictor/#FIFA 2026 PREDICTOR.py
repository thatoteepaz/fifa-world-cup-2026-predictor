"""
================================================================
        FIFA WORLD CUP 2026 MATCH PREDICTOR
        Enhanced Edition — Weighted Scoring Engine
================================================================
Factors used (with weights):
  1. FIFA World Ranking        — 20%
  2. Recent Form (last 5 games)— 25%
  3. Goals scored (last 5)     — 15%
  4. Goals conceded (last 5)   — 10%
  5. Head-to-head record       — 15%
  6. Squad depth (key players) — 10%
  7. Injuries / Suspensions    — 5%
================================================================
"""

def get_int(prompt, min_val=0, max_val=9999):
    while True:
        try:
            val = int(input(prompt))
            if min_val <= val <= max_val:
                return val
            print(f"  ⚠  Please enter a number between {min_val} and {max_val}.")
        except ValueError:
            print("  ⚠  Invalid input. Please enter a whole number.")

def get_float(prompt, min_val=0.0, max_val=9999.0):
    while True:
        try:
            val = float(input(prompt))
            if min_val <= val <= max_val:
                return val
            print(f"  ⚠  Please enter a number between {min_val} and {max_val}.")
        except ValueError:
            print("  ⚠  Invalid input. Please enter a number.")

def form_score(wins, draws, losses):
    """Convert W/D/L into a 0–100 form score."""
    games = wins + draws + losses
    if games == 0:
        return 50  # neutral if no data
    points = (wins * 3) + (draws * 1)
    max_points = games * 3
    return round((points / max_points) * 100, 2)

def rating_score(ranking):
    """
    Convert FIFA ranking to a 0–100 score.
    Rank 1 = 100, Rank 211 = 0 (linear scale).
    """
    return round(max(0, (211 - ranking) / 210 * 100), 2)

def goals_attack_score(goals_for, games=5):
    """Average goals scored per game → 0–100 (cap at 4 goals/game = 100)."""
    avg = goals_for / games if games > 0 else 0
    return round(min(avg / 4 * 100, 100), 2)

def goals_defence_score(goals_against, games=5):
    """Fewer goals conceded is better. 0 conceded = 100, 4+ = 0."""
    avg = goals_against / games if games > 0 else 0
    return round(max(0, (1 - avg / 4) * 100), 2)

def h2h_score(wins, draws, losses):
    """Head-to-head score from this team's perspective."""
    return form_score(wins, draws, losses)

def squad_score(star_players_available, total_key_players=11):
    """
    Ratio of key/star players available vs expected first XI.
    """
    ratio = min(star_players_available / total_key_players, 1.0)
    return round(ratio * 100, 2)

def injury_score(injuries):
    """
    Fewer injured/suspended players = higher score.
    0 injuries = 100, 5+ = 0.
    """
    return round(max(0, (1 - injuries / 5) * 100), 2)

def collect_team_data(team_name):
    print(f"\n{'─'*40}")
    print(f"  📋  Data for: {team_name.upper()}")
    print(f"{'─'*40}")

    data = {}

    # 1. FIFA Ranking
    data['ranking'] = get_int(
        f"  FIFA World Ranking of {team_name} (1–211): ", 1, 211)

    # 2. Recent form — last 5 games
    print(f"\n  📊  Recent Form — Last 5 games for {team_name}")
    data['form_wins']   = get_int("    Wins   (0–5): ", 0, 5)
    data['form_draws']  = get_int("    Draws  (0–5): ", 0, 5)
    data['form_losses'] = get_int("    Losses (0–5): ", 0, 5)

    # 3 & 4. Goals in last 5 games
    print(f"\n  ⚽  Goals — Last 5 games for {team_name}")
    data['goals_scored']   = get_int("    Total goals SCORED   (0–30): ", 0, 30)
    data['goals_conceded'] = get_int("    Total goals CONCEDED (0–30): ", 0, 30)

    # 5. Head-to-head vs opponent (filled after both teams entered)
    # placeholder — filled below
    data['h2h_wins']   = 0
    data['h2h_draws']  = 0
    data['h2h_losses'] = 0

    # 6. Squad — key players available
    data['key_players'] = get_int(
        f"\n  🏅  Key/star players AVAILABLE for {team_name} (0–11): ", 0, 11)

    # 7. Injuries/suspensions
    data['injuries'] = get_int(
        f"  🩹  Injured/suspended players for {team_name} (0–11): ", 0, 11)

    return data

def collect_h2h(team1, team2, d1, d2):
    print(f"\n{'─'*40}")
    print(f"  🔁  Head-to-Head: {team1} vs {team2}")
    print(f"{'─'*40}")
    print(f"  (Enter results from {team1}'s perspective)")
    d1['h2h_wins']   = get_int(f"    {team1} wins   : ", 0, 50)
    d1['h2h_draws']  = get_int(f"    Draws         : ", 0, 50)
    d1['h2h_losses'] = get_int(f"    {team1} losses : ", 0, 50)
    # Mirror for team2
    d2['h2h_wins']   = d1['h2h_losses']
    d2['h2h_draws']  = d1['h2h_draws']
    d2['h2h_losses'] = d1['h2h_wins']

def calculate_score(data):
    """
    Weighted composite score (0–100) for a team.
    """
    GAMES = 5  # reference window

    scores = {
        'ranking':   (rating_score(data['ranking']),                              0.20),
        'form':      (form_score(data['form_wins'], data['form_draws'],
                                  data['form_losses']),                            0.25),
        'attack':    (goals_attack_score(data['goals_scored'], GAMES),             0.15),
        'defence':   (goals_defence_score(data['goals_conceded'], GAMES),          0.10),
        'h2h':       (h2h_score(data['h2h_wins'], data['h2h_draws'],
                                 data['h2h_losses']),                              0.15),
        'squad':     (squad_score(data['key_players']),                            0.10),
        'injuries':  (injury_score(data['injuries']),                              0.05),
    }

    total = sum(s * w for s, w in scores.values())
    return round(total, 2), scores

def predict_scoreline(score1, score2):
    """
    Estimate a rough scoreline based on attack/defence scores.
    Uses the composite score gap as a rough proxy.
    """
    base = 1.2  # average goals per team per game at World Cup
    gap = abs(score1 - score2) / 100

    if score1 > score2:
        g1 = round(base + gap * 2)
        g2 = round(base - gap)
    elif score2 > score1:
        g1 = round(base - gap)
        g2 = round(base + gap * 2)
    else:
        g1 = g2 = round(base)

    return max(g1, 0), max(g2, 0)

def print_breakdown(team, scores, composite):
    labels = {
        'ranking': 'FIFA Ranking',
        'form':    'Recent Form',
        'attack':  'Goals Scored',
        'defence': 'Goals Conceded',
        'h2h':     'Head-to-Head',
        'squad':   'Squad Strength',
        'injuries':'Fitness/Availability',
    }
    print(f"\n  {'─'*36}")
    print(f"  📊  Score breakdown — {team}")
    print(f"  {'─'*36}")
    for key, (val, weight) in scores.items():
        contribution = round(val * weight, 2)
        bar = '█' * int(val / 10)
        print(f"  {labels[key]:<22} {val:>6.1f}/100  (×{weight:.0%} → {contribution:.1f})")
    print(f"  {'─'*36}")
    print(f"  {'COMPOSITE SCORE':<22} {composite:>6.1f}/100")

def win_probability(s1, s2):
    """Simple softmax-style probability split."""
    total = s1 + s2
    if total == 0:
        return 50.0, 50.0
    p1 = round(s1 / total * 100, 1)
    p2 = round(100 - p1, 1)
    return p1, p2

# ─────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────
print("\n" + "=" * 48)
print("    ⚽  FIFA WORLD CUP 2026 MATCH PREDICTOR  ⚽")
print("=" * 48)
print("  Powered by a 7-factor weighted scoring model")
print("  Factors: Ranking · Form · Goals · H2H · Squad")
print("=" * 48)

team1 = input("\n  Enter Team 1 name: ").strip() or "Team 1"
team2 = input("  Enter Team 2 name: ").strip() or "Team 2"

d1 = collect_team_data(team1)
d2 = collect_team_data(team2)
collect_h2h(team1, team2, d1, d2)

# ── Calculate scores ──
comp1, breakdown1 = calculate_score(d1)
comp2, breakdown2 = calculate_score(d2)

# ── Win probability ──
prob1, prob2 = win_probability(comp1, comp2)

# ── Estimated scoreline ──
sg1, sg2 = predict_scoreline(comp1, comp2)

# ── Output ──
print("\n\n" + "=" * 48)
print("              📋  PREDICTION REPORT")
print("=" * 48)

print_breakdown(team1, breakdown1, comp1)
print_breakdown(team2, breakdown2, comp2)

print(f"\n{'═'*48}")
print(f"  🏆  WIN PROBABILITY")
print(f"  {team1:<20}  {prob1:>5}%  {'▓' * int(prob1 // 5)}")
print(f"  {team2:<20}  {prob2:>5}%  {'▓' * int(prob2 // 5)}")

print(f"\n  ⚽  PREDICTED SCORELINE")
print(f"  {team1}  {sg1}  —  {sg2}  {team2}")

print(f"\n  📣  VERDICT", end="  ")
if comp1 > comp2:
    margin = comp1 - comp2
    confidence = "High" if margin > 15 else "Moderate" if margin > 7 else "Slim"
    print(f"{team1} to WIN  [{confidence} confidence]")
elif comp2 > comp1:
    margin = comp2 - comp1
    confidence = "High" if margin > 15 else "Moderate" if margin > 7 else "Slim"
    print(f"{team2} to WIN  [{confidence} confidence]")
else:
    print("Too close to call — likely a DRAW")

print(f"{'═'*48}\n")
print("  ℹ  Disclaimer: Predictions are model-based estimates.")